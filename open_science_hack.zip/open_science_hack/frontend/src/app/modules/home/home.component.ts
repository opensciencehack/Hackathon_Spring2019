import {Component, OnInit} from '@angular/core';


@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
})
export class HomeComponent implements OnInit {
    slideId = 0;
    slides = [
        {
            name: 'The Power of Data'
        },
        {
            name: ''
        },
        {
            name: 'Dataset'
        },
        {
            name: 'Tweets over time'
        },
        {
            name: 'Hashtags'
        },
        {
            name: 'Active'
        },
    ];

    constructor() {

    }

    ngOnInit(): void {

    }


    // --------------------------
    next() {
        if (this.slideId < this.slides.length - 1) {
            ++this.slideId;
        }
    }

    back() {
        if (this.slideId > 0) {
            --this.slideId;
        }
    }

}


