import {Component, OnInit} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {MatDialog} from '@angular/material';
import {ChartsService} from '../../../../shared/services/charts.service';

@Component({
    selector: 'app-dataset',
    templateUrl: './dataset.component.html',

})
export class DatasetComponent implements OnInit {



    constructor(

        private route: ActivatedRoute,
        private dialog: MatDialog
    ) {
    }

    ngOnInit(): void {

    }
}


