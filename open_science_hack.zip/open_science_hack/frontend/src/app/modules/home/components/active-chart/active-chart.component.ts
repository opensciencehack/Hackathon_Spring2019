import {Component, OnInit} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {MatDialog} from '@angular/material';
import {ChartsService} from '../../../../shared/services/charts.service';

@Component({
    selector: 'app-active-chart',
    templateUrl: './active-chart.component.html',

})
export class ActiveChartComponent implements OnInit {
    working = false;
    title = '';
    ngxData = [

    ];

    // options
    showXAxis = true;
    showYAxis = true;
    gradient = false;
    showLegend = false;
    showXAxisLabel = false;
    xAxisLabel = 'Date';
    showYAxisLabel = false;
    yAxisLabel = '';

    colorScheme = {
        domain: ['#5AA454', '#A10A28', '#C7B42C', '#AAAAAA']
    };


    constructor(
        private chartsService: ChartsService,
        private route: ActivatedRoute,
        private dialog: MatDialog
    ) {
    }

    ngOnInit(): void {
        this.get(null);
    }


    // --------------------------
    get(args): void {
        this.working = true;
        this.chartsService.getActive(args)
            .subscribe(
                (data) => {
                    this.working = false;
                    Array.prototype.push.apply(this.ngxData, data.data);
                    this.ngxData = [...this.ngxData];
                }
            )
        ;
    }


    onSelect(event) {

    }
}


