import {Component, OnInit} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {MatDialog} from '@angular/material';
import {ChartsService} from '../../../../shared/services/charts.service';

@Component({
    selector: 'app-word-cloud',
    templateUrl: './word-cloud.component.html',

})
export class WordCloudComponent implements OnInit {



    constructor(

        private route: ActivatedRoute,
        private dialog: MatDialog
    ) {
    }

    ngOnInit(): void {

    }



    onSelect(event) {

    }
}


