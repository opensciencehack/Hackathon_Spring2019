import {Component, OnInit} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {MatDialog} from '@angular/material';
import {ChartsService} from '../../../../shared/services/charts.service';

@Component({
    selector: 'app-tweets-chart',
    templateUrl: './tweets-chart.component.html',

})
export class TweetsChartComponent implements OnInit {
    working = false;
    title = '';
    ngxData: any[] = [
        {
            name: 'Tweets',
            series: []
        }
    ];

    // options
    showXAxis = true;
    showYAxis = true;
    gradient = false;
    showLegend = false;
    showXAxisLabel = false;
    xAxisLabel = 'Date';
    showYAxisLabel = false;
    yAxisLabel = '';

    colorScheme = {
        domain: ['#5AA454', '#A10A28', '#C7B42C', '#AAAAAA']
    };


    constructor(
        private chartsService: ChartsService,
        private route: ActivatedRoute,
        private dialog: MatDialog
    ) {
    }

    ngOnInit(): void {
        this.get(null);
    }


    // --------------------------
    get(args): void {
        this.working = true;
        this.chartsService.getTweets(args)
            .subscribe(
                (data) => {
                    this.working = false;
                    Array.prototype.push.apply(this.ngxData[0].series, data.data);
                    this.ngxData = [...this.ngxData];
                }
            )
        ;
    }


    onSelect(event) {
        
    }
}


