import {NgModule} from '@angular/core';
import {HomeRoutingModule} from './home.routing.module';
import {NgxChartsModule} from '@swimlane/ngx-charts';
import {ChartsService} from '../../shared/services/charts.service';
import {HomeComponent} from './home.component';
import {MaterialModule} from '../../material.module';
import {TweetsChartComponent} from './components/tweets-chart/tweets-chart.component';
import {HashtagsChartComponent} from './components/hashtags-chart/hashtags-chart.component';
import {ActiveChartComponent} from './components/active-chart/active-chart.component';
import {IntroComponent} from './components/intro/intro.component';
import {WordCloudComponent} from './components/word-cloud/word-cloud.component';
import {DatasetComponent} from './components/dataset/dataset.component';


@NgModule({
    imports: [
        MaterialModule,
        HomeRoutingModule,
        NgxChartsModule,
    ],
    declarations: [

        HomeComponent,
        TweetsChartComponent,
        HashtagsChartComponent,
        ActiveChartComponent,
        IntroComponent,
        WordCloudComponent,
        DatasetComponent,
    ],
    providers: [
        ChartsService,

    ],
    entryComponents: []
})
export class HomeModule {
}
