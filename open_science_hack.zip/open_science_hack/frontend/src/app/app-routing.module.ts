import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';

const routes: Routes = [
    {
        path: '',
        loadChildren: './modules/home/home.module#HomeModule?chunkName=home',
    },

];

@NgModule({
    imports: [
        RouterModule.forRoot(
            routes,
            {
                enableTracing: false, // <-- debugging purposes only
                // preloadingStrategy: SelectivePreloadingStrategy,

            }
        )
    ],
    exports: [RouterModule]
})
export class AppRoutingModule {
}
