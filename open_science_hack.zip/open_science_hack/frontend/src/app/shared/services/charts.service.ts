import {Observable} from 'rxjs/internal/Observable';
import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';

@Injectable()
export class ChartsService {
    private path = '/api/charts/';

    constructor(private http: HttpClient
    ) {

    }

    getTweets(args = null): Observable<any> {
        return this.http.get<any>(this.path + 'tweets', {}).pipe();
    }

    getPopularHashtags(args = null): Observable<any> {
        return this.http.get<any>(this.path + 'popular_hashtags', {}).pipe();
    }

    getActive(args = null): Observable<any> {
        return this.http.get<any>(this.path + 'active', {}).pipe();
    }
}
