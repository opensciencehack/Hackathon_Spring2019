const webpack = require('webpack');
const autoprefixer = require('autoprefixer');
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const UglifyJsWebpackPlugin = require('uglifyjs-webpack-plugin');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CleanWebpackPlugin = require('clean-webpack-plugin');

const devModeServer = process.argv[1].indexOf('webpack-dev-server') !== -1;
const devMode = ((process.env.NODE_ENV === 'development') || (devModeServer));
console.log("> " + process.env.NODE_ENV + ' mode');

let devServerPort = 8090;
let pathsToClean = [
  'dist',
  'build'
];

let cleanOptions = {
  verbose: true,
  dry: false
};

module.exports = {
  cache: true,
  entry: {
    app: ['./src/main.ts']
  },
  output: {
    path: __dirname + "/dist",
    publicPath: devModeServer ? "http://localhost:" + devServerPort + "/" : "",
    filename: 'js/[name].js',
    chunkFilename: "js/[name]" + (devMode ? '' : '.[chunkhash:8]') + ".js"
  },
  optimization: {
    //minimize: false,
    splitChunks: {
      cacheGroups: {
        vendors: false,
        default: false,
        common: {
          //test: (m) => isVendor(m.rawRequest),
          test: /node_modules/,
          name: "vendor",
          chunks: "initial",
          enforce: true,
          reuseExistingChunk: true,
          //priority: -20,
        },
      }


    },
    minimizer: [
      new UglifyJsWebpackPlugin({
        parallel: 4,
        uglifyOptions: {
          compress: {
            comparisons: false,
          },
        }
        //test: /\.js($|\?)/i,
        //exclude : 'video.js',
      }),
    ]
  },
  devServer: {
    hot: true,
    inline: true,
    port: devServerPort,
    historyApiFallback: false,
    disableHostCheck: true,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, PATCH, OPTIONS",
      "Access-Control-Allow-Headers": "X-Requested-With, content-type, Authorization"
    }
  },
  devtool: devModeServer ? 'source-map' : false,
  module: {
    //noParse: [ /node_modules(\\|\/)video\.js/ ],
    rules:
      [
        {
          test: /\.ts$/,
          exclude: /node_modules/,
          //parser : { system : true }, // this fix System.import() deprecated
          loaders: [
            {
              loader: 'awesome-typescript-loader',
              options: {
                configFileName: './tsconfig.json'
              }
            },
            'angular2-template-loader',
            'angular-router-loader'
          ]
        }, {
        test: /\.html$/,
        loader: 'html-loader'
      }, {
        test: /\.(scss|css)$/,
        //exclude: [/src/],
        use: [
          MiniCssExtractPlugin.loader, {
            loader: "css-loader",
            options: {
              sourceMap: devMode,
              minimize: {
                safe: false
              }
            }
          }, {
            loader: "postcss-loader",
            options: {
              autoprefixer: {
                browsers: ["last 2 versions"]
              },
              plugins: () => [
                autoprefixer
              ]
            },
          }, {
            loader: "sass-loader",
            options: {}
          }
        ]
      }, {
        loader: 'url-loader?limit=100000',
        test: /\.(png|woff|woff2|eot|ttf|svg)$/
      }

      ]
  },

  resolve: {
    extensions: ['.ts', '.js']
  },

  plugins:
    [
      new webpack.ContextReplacementPlugin(
        // The (\\|\/) piece accounts for path separators in *nix and Windows
        /@angular([\\/])core([\\/])fesm5/,
        __dirname + './src', // location of your src
        {}
        // a map of your routes
      ),
      new MiniCssExtractPlugin({
        filename: "css/[name].css",
        chunkFilename: "css/[name].css"
      }),
      new webpack.DefinePlugin({
        'process.env': {
          'ENV': JSON.stringify(process.env.NODE_ENV)
        }
      }),
      new HtmlWebpackPlugin({
        filename: 'app.blade.php',
        template: 'src/index.html'
      }),
      new CleanWebpackPlugin(pathsToClean, cleanOptions),
    ]
};
if (devMode) {
  module.exports.plugins.push(
    new webpack.HotModuleReplacementPlugin()
  )
}
